/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author User
 */
@WebService(serviceName = "WSOperaciones")
public class WSOperaciones {
    
    List<Login> lista = new ArrayList<Login>();

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Login")
    public Boolean Login(@WebParam(name = "usuarior") String usuario, @WebParam(name = "contrasena") String contrasena) {
        int acum = 0;
        for(int i=0; i<lista.size(); i++){
            Login l = lista.get(i);
            if(usuario.equals(l.getUsuario()) && contrasena.equals(l.getPassword())){
                acum = acum+1;
            }
            if (acum>0){
                return true;
            }
        }
        if(acum>0){
            return true;
        }else {
            return false;
        }
       
    }

    //Registrar Usuario
    @WebMethod(operationName = "RegistrarUsuario")
    public Boolean RegistrarUsuario(@WebParam(name = "usuario") String usuario, @WebParam(name = "clave") String clave, @WebParam(name = "confirmarClave") String confirmarClave,
            @WebParam(name = "saldo") double saldo) {
        Login login = new Login(usuario, clave, saldo);
        if (clave.equals(confirmarClave)) {
            lista.add(login);
            for (int i = 0; i < lista.size(); i++) {
                Login get = lista.get(i);
                System.out.println(get.getUsuario() + " " + get.getPassword());
            }
            return true;
        } else {
            return false;
        }
    }
    
    //Procesar Pago
    @WebMethod(operationName = "ProcesarPago")
    public double ProcesarPago(@WebParam(name = "valorIngresado") double valorIngresado, @WebParam(name = "usuario") String usuario,
            @WebParam(name = "tipoTrans") int tipoTrans) {
        double total = 0;
        int t= lista.size();
        if(lista.size()>0){
             for (int i = 0; i < t; i++) {
            Login l = lista.get(i);
            total = l.getSaldo();
            if (l.getUsuario().equals(usuario)) {
                total=l.getSaldo();
                if (tipoTrans == 1) {
                    total = total + valorIngresado;
                    Login e = new Login(usuario, l.getPassword(), total);
                    lista.set(i, e);
                    return total;
                } else if (tipoTrans == 2 && total >= valorIngresado) {
                    total = total - valorIngresado;
                    Login e = new Login(usuario, l.getPassword(), total);
                    lista.set(i, e);
                    return total;
                } else {
                    total= 0;
                }
                t=0;
            } else {
                total= -1;
            }
        }
        }
       
        return total;

    }
}
