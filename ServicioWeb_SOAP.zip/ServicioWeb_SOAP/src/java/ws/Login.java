package ws;

public class Login {
    private String usuario;
    private String password;
    private double saldo;

    public Login() {
    }
    
    public Login(String usuario, String password, double saldo) {
        this.usuario = usuario;
        this.password = password;
        this.saldo = saldo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }
    
    
}

