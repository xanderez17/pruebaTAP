/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import Controlador.ControladorLogin;
import Vistas.VistaLogin;
import ws.WSOperaciones;
import ws.WSOperaciones_Service;

/**
 *
 * @author User
 */
public class TestWS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Crear el cliente
        WSOperaciones_Service servicio = new WSOperaciones_Service();
        WSOperaciones cliente = servicio.getWSOperacionesPort();
        
        VistaLogin vista = new VistaLogin();
        ControladorLogin ctrl = new ControladorLogin(vista, cliente);
        ctrl.Botones();
    }
    
    
}
