
package Controlador;

import Vistas.MenuIngreso;
import Vistas.VistaLogin;
import Vistas.VistaRegistroLogin;
import ws.WSOperaciones;


public class ControladorLogin {
    
    private VistaLogin vista;
    private WSOperaciones cliente;
    
    //Recibir Vista y Cliente
    public ControladorLogin(VistaLogin login, WSOperaciones servicio) {
        cliente=servicio;
        vista=login;
        vista.setVisible(true);
        vista.setLocationRelativeTo(null);
    }
   
    public void Botones(){
        vista.getBtnIngresar().addActionListener(al-> LoginUsuario());
        vista.getBtnRegistrar().addActionListener(al->Nuevo());
    }
    //Loguear Usuario
   public void LoginUsuario(){
        if (cliente.login(vista.getTxtUsuario().getText(), (vista.getTxtClave().getText()))) {
            MenuIngreso mi = new MenuIngreso();
            ControladorMenu cm = new ControladorMenu(mi, cliente);
            cm.Botones();
            vista.setVisible(false);
            mi.getLblUsuario().setText(vista.getTxtUsuario().getText());
            mi.getLblSaldoActual().setText(cliente.procesarPago(0, vista.getTxtUsuario().getText(), 1)+"");
        } else {
            String a="Credenciales incorrectas o inexistentes";
            vista.getLblMensaje().setText(a);
        }
    }
   
   public void Nuevo(){
       vista.setVisible(false);
       VistaRegistroLogin vrl = new VistaRegistroLogin();
       ControladorRegistro cnu = new ControladorRegistro(vrl, cliente);
       cnu.Botones();
   }
}
