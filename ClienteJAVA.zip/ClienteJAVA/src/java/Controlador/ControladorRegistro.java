/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Vistas.VistaLogin;
import Vistas.VistaRegistroLogin;
import ws.Login;
import ws.WSOperaciones;

/**
 *
 * @author User
 */
public class ControladorRegistro {
    VistaRegistroLogin registro;
    WSOperaciones cliente;

    public ControladorRegistro(VistaRegistroLogin registroUsuario, WSOperaciones cliente1) {
        registro=registroUsuario;
        cliente=cliente1;
        registro.setVisible(true);
        registro.setLocationRelativeTo(null);
    }
    
    public void Botones(){
        registro.getBtnRegistrarUsuario().addActionListener(al-> CrearUsuario());
        registro.getBtnAtras().addActionListener(al-> Atras());
    }
    
    public void Atras(){
        registro.setVisible(false);
        VistaLogin lg = new VistaLogin();
        ControladorLogin ctrl = new ControladorLogin(lg, cliente);
        ctrl.Botones();
        
    }
            
     public void CrearUsuario(){
        if (cliente.registrarUsuario(registro.getTxtIngresarUsuario().getText(),registro.getTxtIngresarClave().getText(), registro.getTxtRepetirClave().getText(), Double.parseDouble(registro.getTxtSaldo().getText()))) {
            registro.getTxtMensajeEmergente().setText("Usuario registrado con éxito");
            Limpiar();
        } else {
            System.out.println("Error");
            registro.getTxtMensajeEmergente().setText("Claves inconsistentes");
        }
    }
     
     public void Limpiar(){
         registro.getTxtIngresarUsuario().setText("");
         registro.getTxtIngresarClave().setText("");
         registro.getTxtRepetirClave().setText("");
         registro.getTxtSaldo().setText("");
     }
}
