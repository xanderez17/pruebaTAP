/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Vistas.MenuIngreso;
import Vistas.VistaLogin;
import ws.WSOperaciones;

/**
 *
 * @author User
 */
public class ControladorMenu {
    MenuIngreso menu;
    WSOperaciones cliente;

    public ControladorMenu(MenuIngreso menu, WSOperaciones cliente) {
        this.menu = menu;
        this.cliente = cliente;
        this.menu.setVisible(true);
        this.menu.setLocationRelativeTo(null);
    }
    
    public void Botones(){
        menu.getBtnIngresar().addActionListener(al-> RegistroLogin());
        menu.getBtnAtras().addActionListener(al-> Atras());
        
    }
    
    public void Atras(){
        menu.setVisible(false);
        VistaLogin vstlog = new VistaLogin();
        ControladorLogin ctrl = new ControladorLogin(vstlog, cliente);
        ctrl.Botones();
    }
       public void RegistroLogin(){
        double num=Double.parseDouble(menu.getTxtValorDeposito().getText());
        double saldofinal = Double.parseDouble(menu.getLblSaldoActual().getText());
        String user=menu.getLblUsuario().getText();
        if (menu.getRdbtnDeposito().isSelected()) {
            saldofinal=cliente.procesarPago(num, user, 1);
            menu.getLblMensaje().setText("Depósito exitoso");
        } else if(menu.getRdbtnRetiro().isSelected()){
            saldofinal=cliente.procesarPago(num, user, 2);
            menu.getLblMensaje().setText("Retiro exitoso");
        } else {
            menu.getLblMensaje().setText("Seleccione una opción");
        }
        if (saldofinal==0) {
            menu.getLblMensaje().setText("ERROR-Insuficiente");
            saldofinal=cliente.procesarPago(0, user, 1);
            menu.getLblSaldoActual().setText(saldofinal+"");
        } else {
            menu.getLblSaldoActual().setText(saldofinal+"");
        }
        
    }
}
